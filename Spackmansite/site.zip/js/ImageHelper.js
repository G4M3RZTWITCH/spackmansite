function getHomepageViewModel() {
    
    return {"homepage" : {
                "images" : [
                    {"url" : "img/Collage1.jpg", "alt" : "image1", "title" : "collage1"},
                    {"url" : "img/Collage2.jpg", "alt" : "image2", "title" : "collage2"},
                    {"url" : "img/Collage3.jpg", "alt" : "image3", "title" : "collage3"},
                    {"url" : "img/Collage4.jpg", "alt" : "image4", "title" : "collage4"},
                    {"url" : "img/Collage5.jpg", "alt" : "image5", "title" : "collage5"},
                    {"url" : "img/Collage6.jpg", "alt" : "image6", "title" : "collage6"}
                ]}
           };
}